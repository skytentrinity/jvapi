from sqlalchemy import Column, Integer, String
from .database import Base

class UserDB(Base):
    __tablename__ = "User"
    Id = Column(Integer, primary_key=True, index=True)
    Login = Column(String(150), unique=True, index=True, nullable=False)
    PassHash = Column(String(128), nullable=False)
