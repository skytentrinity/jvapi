from sqlalchemy.orm import Session
from . import models, schemas

def create_user(db: Session, user: schemas.UserCreate):
    db_user = models.UserDB(Login=user.Login, PassHash=user.PassHash)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user(db: Session, user_id: int):
    return db.query(models.UserDB).filter(models.UserDB.Id == user_id).first()

def get_user_by_login(db: Session, login: str):
    return db.query(models.UserDB).filter(models.UserDB.Login == login).first()

def update_user(db: Session, db_user: models.UserDB, payload: schemas.UserUpdate):
    if payload.Login:
        db_user.Login = payload.Login
    if payload.PassHash:
        db_user.PassHash = payload.PassHash
    db.commit()
    db.refresh(db_user)
    return db_user

def delete_user(db: Session, db_user: models.UserDB):
    db.delete(db_user)
    db.commit()

def get_users(db: Session):
    return db.query(models.User).all()
