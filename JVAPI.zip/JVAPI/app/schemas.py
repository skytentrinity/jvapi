import re
from pydantic import BaseModel, Field, validator
from typing import Optional

HEX_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")

class UserCreate(BaseModel):
    Login: str = Field(..., min_length=3, max_length=150)
    PassHash: str

    @validator("PassHash")
    def passhash_must_be_sha256_hex(cls, v):
        if not HEX_SHA256_RE.fullmatch(v):
            raise ValueError("PassHash must be a SHA-256 hex string")
        return v.lower()

class UserOut(BaseModel):
    Id: int
    Login: str

class UserUpdate(BaseModel):
    Login: Optional[str] = None
    PassHash: Optional[str] = None

    @validator("PassHash")
    def passhash_must_be_sha256_hex(cls, v):
        if v and not HEX_SHA256_RE.fullmatch(v):
            raise ValueError("PassHash must be a SHA-256 hex string")
        return v.lower() if v else v
